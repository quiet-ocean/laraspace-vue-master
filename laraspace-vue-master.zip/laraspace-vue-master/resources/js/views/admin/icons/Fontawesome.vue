<template>
  <div class="main-content">
    <div class="page-header">
      <h4 class="page-title">Font Awesome</h4>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item"><a href="#">Icons</a></li>
        <li class="breadcrumb-item"><a href="#">Font Awesome</a></li>
      </ol>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h6>Example Usage</h6>
          </div>
          <div class="card-body">
            <pre class="language-html"><code>&lt;i class="icon-fa icon-fa-adjust"&gt;&lt;/i&gt;</code></pre>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <h4 class="page-header">Web Application Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-adjust"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- adjust</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-american-sign-language-interpreting"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-american-sign-language-interpreting</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-anchor"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-anchor</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-archive"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-archive</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-area-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-area-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrows</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-h"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrows-h</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-v"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrows-v</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-asl-interpreting"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-asl-interpreting</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-assistive-listening-systems"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-assistive-listening-systems</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-asterisk"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-asterisk</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-at"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-at</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-audio-description"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-audio-description</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-automobile"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-automobile</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-balance-scale"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-balance-scale</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ban"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ban</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bank"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bank</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bar-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bar-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bar-chart-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bar-chart-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-barcode"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-barcode</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bars"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bars</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-0"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-0</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-1"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-1(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-2"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-2(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-3"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-3(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-4"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-4(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-empty"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- battery-empty</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-full"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-full</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-half"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-half</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-quarter"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-quarter</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-battery-three-quarters"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-battery-three-quarters</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bed"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bed</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-beer"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-beer</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bell"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bell</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bell-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bell-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bell-slash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bell-slash</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bell-slash-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bell-slash-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bicycle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bicycle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-binoculars"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-binoculars</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-birthday-cake"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-birthday-cake</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-blind"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-blind</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bluetooth"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bluetooth</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bluetooth-b"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bluetooth-b</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bolt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bolt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bomb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bomb</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-book"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-book</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bookmark"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bookmark</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bookmark-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bookmark-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-braille"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-braille</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-briefcase"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-briefcase</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bug"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bug</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-building"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-building</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-building-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-building-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bullhorn"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bullhorn</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bullseye"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bullseye</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cab"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cab(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calculator"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calculator</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar-check-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar-check-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar-minus-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar-minus-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar-plus-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar-plus-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-calendar-times-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-calendar-times-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-camera"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-camera</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-camera-retro"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-camera-retro</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-car"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-car</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cart-arrow-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cart-arrow-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cart-plus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cart-plus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-certificate"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-certificate</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-child"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-child</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle-o-notch"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle-o-notch</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle-thin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle-thin</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-clock-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-clock-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-clone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-clone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-close"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-close(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cloud"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cloud</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cloud-download"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cloud-download</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cloud-upload"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cloud-upload</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-code"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-code</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-code-fork"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-code-fork</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-coffee"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-coffee</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cog"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cog</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cogs"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cogs</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-comment"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-comment</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-comment-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-comment-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-commenting"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-commenting</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-commenting-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-commenting-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-comments"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-comments</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-comments-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-comments-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-compass"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-compass</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-copyright"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-copyright</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-creative-commons"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-creative-commons</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-credit-card"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-credit-card</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-credit-card-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-credit-card-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-crop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-crop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-crosshairs"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-crosshairs</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cube"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cube</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cubes"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cubes</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cutlery"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cutlery</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dashboard"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dashboard(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-database"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-database</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-deaf"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-deaf</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-deafness"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-deafness</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-desktop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-diamond</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dot-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dot-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-edit"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-edit(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ellipsis-h"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ellipsis-h</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ellipsis-v"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ellipsis-v</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-envelope"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-envelope</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-envelope-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-envelope-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-envelope-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-envelope-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eraser"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eraser</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-exchange"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-exchange</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-exclamation"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-exclamation</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-exclamation-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-exclamation-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-exclamation-triangle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-exclamation-triangle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-external-link"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-external-link</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-external-link-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-external-link-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eye"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- eye
                  </span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eye-slash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eye-slash</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eyedropper"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eyedropper</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fax"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fax</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-feed"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-feed(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-female"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-female</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fighter-jet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fighter-jet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-archive-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-archive-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-audio-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-audio-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-code-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-code-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-excel-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-excel-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-image-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-image-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-movie-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-movie-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-pdf-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-pdf-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-photo-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-photo-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-picture-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-picture-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-powerpoint-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-powerpoint-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-sound-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-sound-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-video-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-video-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-word-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-word-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-zip-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-zip-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-film"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-film</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-filter"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-filter</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fire-extinguisher"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fire-extinguisher</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flag"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flag</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flag-checkered"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flag-checkered</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flag-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flag-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flash>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flask"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flask</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-folder"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-folder</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-folder-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-folder-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-folder-open"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-folder-open</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-folder-open-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-folder-open-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-frown-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-frown-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-futbol-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-futbol-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gamepad"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gamepad</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gavel"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gavel</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gear"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gear(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gears"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gears>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gift"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gift</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-glass"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-glass</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-globe"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-globe</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-graduation-cap"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-graduation-cap</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-group"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-group>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-grab-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-grab-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-lizard-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-lizard-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-paper-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-paper-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-peace-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-peace-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-pointer-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-pointer-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-rock-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-rock-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-scissors-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-scissors-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-spock-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-spock-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-stop-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-stop-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hard-of-hearing"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hard-of-hearing(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hashtag"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hashtag</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hdd-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hdd-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-headphones"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-headphones</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heart-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heart-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heartbeat"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heartbeat</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-history"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-history</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-home"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-home</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hotel"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hotel>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-1"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-1(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-2"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-2(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-3"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-3(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-end"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-end</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-half"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-half</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hourglass-start"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hourglass-start</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-i-cursor"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-i-cursor</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-image"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-image(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-inbox"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-inbox</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-industry"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-industry</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-info"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-info</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-info-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-info-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-institution"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-institution(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-key"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-key</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-keyboard-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-keyboard-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-language"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-language</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-laptop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-laptop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-leaf"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-leaf</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-legal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-legal(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-lemon-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-lemon-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-level-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-level-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-level-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-level-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-life-bouy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-life-bouy(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-life-buoy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-life-buoy(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-life-ring"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-life-ring</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-life-saver"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-life-saver(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-lightbulb-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-lightbulb-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-line-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-line-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-location-arrow"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-location-arrow</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-lock"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-lock</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-low-vision"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-low-vision</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-magic"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-magic</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-magnet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-magnet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mail-forward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mail-forward(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mail-reply"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mail-reply(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mail-reply-all"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mail-reply-all(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-male"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-male</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-map"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-map</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-map-marker"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-map-marker</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-map-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-map-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-map-pin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-map-pin</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-map-signs"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-map-signs</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-meh-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-meh-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-microphone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-microphone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-microphone-slash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-microphone-slash</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mobile"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mobile</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mobile-phone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mobile-phone(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-money"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-money</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-moon-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-moon-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mortar-board"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mortar-board(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-motorcycle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-motorcycle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mouse-pointer"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mouse-pointer</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-music"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-music</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-navicon"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-navicon(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-newspaper-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-newspaper-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-object-group"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-object-group</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-object-ungroup"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-object-ungroup</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paint-brush"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paint-brush</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paper-plane"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paper-plane</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paper-plane-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paper-plane-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paw"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paw</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pencil"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pencil</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pencil-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pencil-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pencil-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pencil-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-percent"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-percent</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-phone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-phone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-phone-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-phone-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-photo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-photo>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-picture-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-picture-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pie-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pie-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plane"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plane</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plug"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plug</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-power-off"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-power-off</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-print"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-print</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-puzzle-piece"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-puzzle-piece</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-qrcode"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-qrcode</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-question"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-question</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-question-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-question-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-question-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-question-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-quote-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-quote-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-quote-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-quote-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-random"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-random</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-recycle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-recycle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-refresh"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-refresh</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-registered"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-registered</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-remove"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-remove>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reorder"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reorder>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reply"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reply</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reply-all"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reply-all</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-retweet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-retweet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-road"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-road</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rocket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rocket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rss"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rss</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rss-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rss-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-search"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-search</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-search-minus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-search-minus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-search-plus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-search-plus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-send"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-send(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-send-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-send-o>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-server"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-server</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-alt-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-alt-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shield"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shield</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ship"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ship</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shopping-bag"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shopping-bag</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shopping-basket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shopping-basket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shopping-cart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shopping-cart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sign-in"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sign-in</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sign-language"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sign-language</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sign-out"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sign-out</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-signal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-signal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-signing"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-signing>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sitemap"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sitemap</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sliders"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sliders</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-smile-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-smile-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-soccer-ball-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-soccer-ball-o>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-alpha-asc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-alpha-asc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-alpha-desc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-alpha-desc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-amount-asc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-amount-asc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-amount-desc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-amount-desc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-asc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-asc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-desc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-desc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-down>(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-numeric-asc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-numeric-asc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-numeric-desc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-numeric-desc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sort-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sort-up(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-space-shuttle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-space-shuttle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-spinner"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-spinner</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-spoon"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-spoon</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star-half"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star-half</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star-half-empty"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star-half-empty(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star-half-full"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star-half-full(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star-half-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star-half-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-star-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-star-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sticky-note"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sticky-note</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sticky-note-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sticky-note-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-street-view"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-street-view</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-suitcase"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-suitcase</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sun-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sun-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-support"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-support(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tablet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tablet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tachometer"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tachometer</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tag"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tag</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tags"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tags</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tasks"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tasks</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-taxi"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-taxi</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-television"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-television</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-terminal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-terminal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumb-tack"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumb-tack</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ticket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ticket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-times"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-times</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-times-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-times-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-times-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-times-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tint"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tint</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-down(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-left(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-off"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-off</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-on"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-on</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-right(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-up(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-trademark"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-trademark</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-trash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-trash</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-trash-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-trash-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tree"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tree</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-trophy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-trophy</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-truck"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-truck</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tty"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- tty</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tv"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tv(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-umbrella"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-umbrella</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-universal-access"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-universal-access</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-university"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-university</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-unlock"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-unlock</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-unlock-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-unlock-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-unsorted"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-unsorted(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-upload"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-upload</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user-plus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user-plus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user-secret"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user-secret</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user-times"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user-times</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-users"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-users</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-video-camera"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-video-camera</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-volume-control-phone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-volume-control-phone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-volume-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-volume-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-volume-off"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-volume-off</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-volume-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-volume-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-warning"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-warning(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wheelchair</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wheelchair-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wifi"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wifi</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wrench"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wrench</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Accessibility Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-american-sign-language-interpreting"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-american-sign-language-interpreting</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-asl-interpreting"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-asl-interpreting(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-assistive-listening-systems"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-assistive-listening-systems</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-audio-description"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-audio-description</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-blind"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-blind</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-braille"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-braille</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-deaf"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-deaf</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-deafness"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-deafness(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hard-of-hearing"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hard-of-hearing(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-low-vision"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-low-vision</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-question-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-question-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sign-language"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sign-language</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-signing"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-signing(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tty"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tty</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-universal-access"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-universal-access</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-volume-control-phone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-volume-control-phone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair-alt</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Hand Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-grab-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-grab-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-lizard-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-lizard-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-paper-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-paper-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-peace-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-peace-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-pointer-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-pointer-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-rock-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-rock-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-scissors-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-scissors-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-spock-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-spock-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-stop-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-stop-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-thumbs-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-thumbs-up</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Transportation Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ambulance"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ambulance</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-automobile"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-automobile(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bicycle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bicycle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cab"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cab(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-car"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-car</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fighter-jet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fighter-jet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-motorcycle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-motorcycle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plane"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plane</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rocket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rocket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ship"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ship</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-space-shuttle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-space-shuttle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-subway"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-subway</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-taxi"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-taxi</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-train"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-train</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-truck"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-truck</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair-alt</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Gender Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-genderless"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- genderless</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-intersex"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- intersex(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mars"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mars</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mars-double"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mars-double</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mars-stroke"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mars-stroke</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mars-stroke-h"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mars-stroke-h</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mars-stroke-v"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mars-stroke-v</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mercury"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-mercury</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-neuter"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-neuter</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-transgender"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-transgender</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-transgender-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-transgender-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-venus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-venus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-venus-double"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-venus-double</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-venus-mars"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-venus-mars</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">File Type Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-archive-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-archive-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-audio-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-audio-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-code-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-code-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-excel-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-excel-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-image-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-image-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-movie-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- file-movie-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-pdf-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-pdf-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-photo-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-photo-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-picture-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-picture-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-powerpoint-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-powerpoint-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-sound-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-sound-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-text"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-text</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-text-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-text-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-video-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-video-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-word-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-word-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-zip-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-zip-o</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Spinner Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle-o-notch"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- circle-o-notch</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cog"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cog</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gear"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gear(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-refresh"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-refresh</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-spinner"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-spinner</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Form Control Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-check-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-check-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dot-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dot-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-minus-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-minus-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-square-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-square-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-square-o</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Payment Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-amex"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-amex</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-diners-club"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-diners-club</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-discover"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-discover</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-jcb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-jcb</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-mastercard"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-mastercard</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-paypal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-paypal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-stripe"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-stripe</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-visa"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-visa</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-credit-card"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-credit-card</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-credit-card-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-credit-card-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-google-wallet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-google-wallet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paypal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paypal</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Chart Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-area-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-area-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bar-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bar-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bar-chart-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bar-chart-o(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-line-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-line-chart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pie-chart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pie-chart</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Currency Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bitcoin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bitcoin(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-btc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-btc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cny"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cny(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dollar"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dollar(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eur"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eur</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-euro"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-euro(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gbp"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gbp</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gg"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gg</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gg-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gg-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ils"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ils</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-inr"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-inr</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-jpy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-jpy</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-krw"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-krw</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-money"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-money</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rmb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rmb(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rouble"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rouble(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rub"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rub</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ruble"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ruble(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rupee"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rupee(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shekel"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shekel(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sheqel"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sheqel(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-try"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-try</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-turkish-lira"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-turkish-lira(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-usd"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-usd</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-won"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-won(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-yen"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-yen(alias)</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Text Editor Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-align-center"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-align-center</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-align-justify"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-align-justify</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-align-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-align-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-align-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-align-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bold"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bold</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chain"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chain(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chain-broken"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chain-broken</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-clipboard"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-clipboard</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-columns"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-columns</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-copy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-copy(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cut"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cut(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dedent"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dedent(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eraser"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eraser</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-text"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-text</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-file-text-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-file-text-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-files-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-files-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-floppy-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-floppy-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-font"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-font</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-header"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-header</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-indent"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-indent</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-italic"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-italic</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-link"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-link</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-list"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-list</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-list-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-list-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-list-ol"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-list-ol</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-list-ul"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-list-ul</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-outdent"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-outdent</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paperclip"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paperclip</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paragraph"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paragraph</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paste"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paste(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-repeat"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-repeat</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rotate-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rotate-left(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rotate-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rotate-right(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-save"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-save(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-scissors"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-scissors</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-strikethrough"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-strikethrough</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-subscript"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-subscript</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-superscript"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-superscript</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-table"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-table</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-text-height"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-text-height</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-text-width"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-text-width</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-th"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-th</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-th-large"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-th-large</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-th-list"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-th-list</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-underline"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-underline</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-undo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-undo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-unlink"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-unlink(alias)</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Directional Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-double-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-double-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-double-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-double-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-double-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-double-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-double-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-double-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angle-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angle-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrow-circle-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrow-circle-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrow-circle-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-o-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrow-circle-o-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-o-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-circle-o-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-circle-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-circle-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-circle-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-circle-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrow-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrow-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrows</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrows-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-h"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrows-h</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-v"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- arrows-v</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- caret-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- caret-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- caret-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- caret-square-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- caret-square-o-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-square-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-square-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-caret-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-caret-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-circle-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-circle-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-circle-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-circle-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-circle-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-circle-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-circle-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-circle-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chevron-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chevron-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-exchange"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-exchange</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hand-o-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hand-o-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-long-arrow-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-long-arrow-down</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-long-arrow-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-long-arrow-left</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-long-arrow-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-long-arrow-right</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-long-arrow-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-long-arrow-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-down"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-down(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-left"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-left(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-right"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-right(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-toggle-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-toggle-up(alias)</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Video Player Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-arrows-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-arrows-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-backward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-backward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-compress"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-compress</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-eject"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-eject</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-expand"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-expand</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fast-backward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fast-backward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fast-forward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fast-forward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-forward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-forward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pause"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pause</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pause-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pause-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pause-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pause-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-play"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-play</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-play-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-play-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-play-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-play-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-random"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-random</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-step-backward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-step-backward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-step-forward"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-step-forward</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stop-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stop-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stop-circle-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stop-circle-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-youtube-play"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-youtube-play</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Brand Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-500px"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-500px</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-adn"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- adn</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-amazon"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-amazon</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-android"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-android</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-angellist"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-angellist</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-apple"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-apple</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-behance"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-behance</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-behance-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-behance-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bitbucket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bitbucket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bitbucket-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bitbucket-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bitcoin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bitcoin(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-black-tie"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-black-tie</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bluetooth"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bluetooth</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-bluetooth-b"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-bluetooth-b</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-btc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-btc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-buysellads"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-buysellads</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-amex"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-amex</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-diners-club"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-diners-club</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-discover"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-discover</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-jcb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-jcb</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-mastercard"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-mastercard</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-paypal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-paypal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-stripe"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-stripe</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-cc-visa"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-cc-visa</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-chrome"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-chrome</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-codepen"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-codepen</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-codiepie"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-codiepie</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-connectdevelop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-connectdevelop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-contao"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-contao</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-css3"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-css3</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dashcube"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dashcube</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-delicious"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-delicious</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-deviantart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-deviantart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-digg"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-digg</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dribbble"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dribbble</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-dropbox"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-dropbox</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-drupal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-drupal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-edge"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-edge</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-empire"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-empire</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-envira"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-envira</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-expeditedssl"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-expeditedssl</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-facebook"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-facebook</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-facebook-f"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-facebook-f(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-facebook-official"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-facebook-official</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-facebook-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-facebook-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-firefox"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-firefox</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-flickr"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-flickr</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fonticons"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fonticons</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-fort-awesome"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-fort-awesome</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-forumbee"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-forumbee</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-foursquare"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-foursquare</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ge"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ge(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-get-pocket"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-get-pocket</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gg"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gg</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gg-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gg-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-git"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-git</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-git-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-git-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-github"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-github</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-github-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-github-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-github-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-github-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gitlab"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gitlab</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gittip"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-gittip(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-glide"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-glide</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-glide-g"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-glide-g</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-google"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-google</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-google-plus"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-google-plus</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-google-plus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- google-plus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-google-wallet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- google-wallet</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-gratipay"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- gratipay</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hacker-news"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- hacker-news</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-houzz"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- houzz</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-html5"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- html5</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-instagram"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- instagram</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-internet-explorer"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- internet-explorer</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ioxhost"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- ioxhost</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-joomla"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- joomla</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-jsfiddle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- jsfiddle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-lastfm"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- lastfm</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-lastfm-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- lastfm-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-leanpub"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- leanpub</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-linkedin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- linkedin</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-linkedin-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- linkedin-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-linux"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- linux</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-maxcdn"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- maxcdn</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-meanpath"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- meanpath</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-medium"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- medium</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-mixcloud"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- mixcloud</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-modx"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- modx</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-odnoklassniki"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- odnoklassniki</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-odnoklassniki-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-odnoklassniki-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-opencart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-opencart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-openid"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-openid</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-opera"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-opera</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-optin-monster"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-optin-monster</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pagelines"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pagelines</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-paypal"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-paypal</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pied-piper"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pied-piper</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pied-piper-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pied-piper-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pinterest"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pinterest</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pinterest-p"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pinterest-p</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-pinterest-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-pinterest-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-product-hunt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-product-hunt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-qq"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-qq</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ra"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ra(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-rebel"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-rebel</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reddit"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reddit</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reddit-alien"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reddit-alien</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-reddit-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-reddit-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-renren"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-renren</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-safari"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-safari</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-scribd"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-scribd</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-sellsy"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-sellsy</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-alt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-share-alt-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-share-alt-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-shirtsinbulk"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-shirtsinbulk</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-simplybuilt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-simplybuilt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-skyatlas"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-skyatlas</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-skype"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-skype</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-slack"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-slack</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-slideshare"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-slideshare</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-snapchat"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-snapchat</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-snapchat-ghost"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-snapchat-ghost</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-snapchat-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-snapchat-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-soundcloud"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-soundcloud</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-spotify"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-spotify</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stack-exchange"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stack-exchange</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stack-overflow"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stack-overflow</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-steam"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-steam</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-steam-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-steam-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stumbleupon"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stumbleupon</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stumbleupon-circle"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stumbleupon-circle</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tencent-weibo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tencent-weibo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-trello"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-trello</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tripadvisor"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tripadvisor</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tumblr"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tumblr</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-tumblr-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-tumblr-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-twitch"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-twitch</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-twitter"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-twitter</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-twitter-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-twitter-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-usb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-usb</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-viacoin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- viacoin</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-viadeo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- viadeo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-viadeo-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- viadeo-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-vimeo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- vimeo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-vimeo-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- vimeo-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-vine"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- vine</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-vk"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-vk</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wechat"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wechat(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-weibo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- weibo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-weixin"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- weixin</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-whatsapp"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- whatsapp</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wikipedia-w"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wikipedia-w</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-windows"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- windows</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wordpress"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wordpress</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wpbeginner"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wpbeginner</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wpforms"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- wpforms</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-xing"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- xing</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-xing-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- xing-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-y-combinator"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- y-combinator</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-y-combinator-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- y-combinator-square(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-yahoo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- yahoo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-yc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-yc(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-yc-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- yc-square(alias)</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-yelp"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- yelp</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-youtube"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- youtube</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-youtube-play"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- youtube-play</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-youtube-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa- youtube-square</span>
                </div>
              </div>
            </div>
            <br>
            <h4 class="page-header">Medical Icons</h4>
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-ambulance"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-ambulance</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-h-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-h-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heart-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heart-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-heartbeat"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-heartbeat</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-hospital-o"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-hospital-o</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-medkit"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-medkit</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-plus-square"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-plus-square</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-stethoscope"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-stethoscope</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-user-md"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-user-md</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-fa icon-fa-wheelchair-alt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-fa-wheelchair-alt</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
