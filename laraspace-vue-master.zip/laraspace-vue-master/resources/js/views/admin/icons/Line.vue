<template>
  <div class="main-content">
    <div class="page-header">
      <h3 class="page-title">Line Icons</h3>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item"><a href="#">Icons</a></li>
        <li class="breadcrumb-item"><a href="#">Line Icons</a></li>
      </ol>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h6>Example Usage</h6>
          </div>
          <div class="card-body">
            <pre class="language-html"><code>&lt;i class="icon-ln icon-ln-music"&gt;&lt;/i&gt;</code></pre>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <div class="icon-container">
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-music"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-music</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-search"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-search</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-mail"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-mail</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-heart"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-heart</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-star"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-star</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-user"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-user</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-videocam"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-videocam</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-camera"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-camera</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-photo"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-photo</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-attach"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-attach</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-lock"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-lock</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-eye"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-eye</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-tag"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-tag</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-thumbs-up"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-thumbs-up</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-pencil"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-pencil</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-comment"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-comment</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-location"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-location</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-cup"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-cup</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-trash"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-trash</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-doc"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-doc</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-note"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-note</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-cog"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-cog</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-params"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-params</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-calendar"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-calendar</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-sound"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-sound</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-clock"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-clock</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-lightbulb"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-lightbulb</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-tv"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-tv</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-desktop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-desktop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-mobile"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-mobile</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-cd"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-cd</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-inbox"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-inbox</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-globe"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-globe</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-cloud"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-cloud</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-paper-plane"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-paper-plane</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-fire"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-fire</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-graduation-cap"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-graduation-cap</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-megaphone"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-megaphone</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-database"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-database</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-key"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-key</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-beaker"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-beaker</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-truck"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-truck</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-money"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-money</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-food"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-food</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-shop"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-shop</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-diamond"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-diamond</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-t-shirt"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-t-shirt</span>
                </div>
              </div>
              <div class="demo-icon">
                <div class="icon-box">
                  <i class="icon-ln icon-ln-wallet"/>
                </div>
                <div class="icon-classname">
                  <span>icon-ln-wallet</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
