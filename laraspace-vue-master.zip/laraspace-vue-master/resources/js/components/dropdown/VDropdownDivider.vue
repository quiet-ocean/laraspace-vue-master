<template>
  <div class="dropdown-item-divider"/>
</template>
